
# GG_Backend

Flask based GG_Backend V0.0.1



# GG_Backend

Flask based GG_Backend V0.0.1


## Installation

Upgrade PIP to latest version

```bash
  pip install --upgrade pip
```

Install project dependencies (Make sure they're updated)

```bash
  pip install -r ./requirements.txt
```
    
Run custom virtual environment in Terminal
- For MacOS

```bash
  source venv/bin/activate
```
- For Windows
```bash
  venv/bin/activate
```
## Usage/Examples

```bash
python app.py
```
And go to: http://localhost:5000/apidocs/
